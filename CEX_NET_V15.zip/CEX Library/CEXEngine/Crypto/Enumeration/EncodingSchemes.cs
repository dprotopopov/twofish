﻿namespace VTDev.Libraries.CEXEngine.Crypto.Enumeration
{
    public enum EncodingSchemes : int
    {
        CER = 1,
        DER = 2,
        PEM = 4
    }
}
